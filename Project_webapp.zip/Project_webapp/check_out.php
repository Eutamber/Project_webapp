<?php 
$connect = new mysqli('localhost', 'root', '', 'project_webapp',);

if ($connect->connect_error) {
    die("Something wrong.: " . $connect->connect_error);
}


$sql = "SELECT * FROM `ฺbasket`";  
$result = $connect->query($sql);
$total = 0; 

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $total += $row['price'];
    }
}$result->data_seek(0);



?>





<!DOCTYPE html>
<html>
<head>
    <title>Checkout</title>
    <link rel="stylesheet" type="text/css" href="styless.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
    .container {
        display: flex;
        justify-content: space-between;
    }

    .container a {
        display: flex;
        align-items: center;
        background-color: rgb(233, 252, 252);
        color: darkcyan;
        text-decoration: none;
        transition: opacity 0.3s ease; /* Add a transition for a smooth effect */
        padding: 10px 20px; /* Adjust padding as needed */
    }

    .container a:first-child {
        margin-right: 300px; /* Add margin to the right of the first button */
    }

    .container a:last-child {
        margin-left: 10px; /* Add margin to the left of the second button */
    }

    .container a:hover {
        opacity: 0.8; /* Reduce opacity on hover (you can adjust the value) */
    }
</style>

</head>
<body>
    <div class="checkout-container">
        <div class="checkout-form">
            <div class="container">
            <div class="container" style="display: flex; justify-content: space-between;">
    <a href="shoping-cart.php">
        &lt; Shopping Cart
    </a>
    <a href="payment-success.html">
         next &gt;
    </a>
</div>

           
            </div>
            <p><i class="fas fa-plane" style="color: rgb(112, 156, 239);"></i></p>
            <h2>Checkout</h2>
            <h3>Delivery time will not exceed 7 working days.</h3>
            <form>
                <div class="form-group">
                    <label for="name">Name:</label>
                    <input type="text" id="name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="address">Address:</label>
                    <textarea id="address" name="address" required></textarea>
                </div>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required>
                </div>
                
                <h3>After transferring, the company will check the balance and then deliver the items.</h3>
                

                
            </div>
            <div class="order-summary">
                <h2>Order Summary</h2>
                <h3>Pay the transfer at this qrcode</h3>
                <ul id="product-list"></ul>
                <img src="Qrcodepay123.jpg" class="Qrcodebank" alt="QR Code"></img>
                <p>Total: <?php echo number_format($total, ); ?> BATH</p>
            </div>
        </div>
    </div>
    <script src="scriptt.js"></script>

</body>
</html>


